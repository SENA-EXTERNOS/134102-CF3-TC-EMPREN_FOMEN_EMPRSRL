function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6SPciZ2W4wq":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

